#include "pch.h"
#include "Game.h"

Game::Game() {
    // Implementa��o do construtor
}
