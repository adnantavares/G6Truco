#include "pch.h"
#include "Deck.h"

Deck::Deck() {
    // Implementa��o do construtor
}
